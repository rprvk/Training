package com.mycompany.conferenceweb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceWeb1Application {

	public static void main(String[] args) {
		SpringApplication.run(ConferenceWeb1Application.class, args);
	}

}
