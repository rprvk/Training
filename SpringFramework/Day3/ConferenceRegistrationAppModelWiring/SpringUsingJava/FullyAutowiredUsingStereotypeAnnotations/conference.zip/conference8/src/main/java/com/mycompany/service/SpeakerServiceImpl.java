package com.mycompany.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.model.Speaker;
import com.mycompany.repository.SpeakerRepository;

@Service("speakerService")
public class SpeakerServiceImpl implements SpeakerService {

	private SpeakerRepository repository;//private SpeakerRepository repository = new HibernateSpeakerRepositoryImpl();
												//now it is no more hardcoded
	
	@Override
	public List<Speaker> findAll() {  //using finder methods

		return repository.findAll();
	}

	public SpeakerServiceImpl() {
		System.out.println("speakerServiceImplt no args Constructor");
	}

	@Autowired  //it will automatically inject speakerRepository bean into this setup
	public void setRepository(SpeakerRepository repository) {
		System.out.println("speakerServiceImplt setter");
		this.repository = repository;
	}

	public SpeakerServiceImpl(SpeakerRepository speakerRepository) {
		System.out.println("speakerServiceImplt repository Constructor");
		
		repository = speakerRepository;
	}  //using constructor and chAnging names

}

//since bean is at method level, we use stereotype annotations like service,component,repository at class