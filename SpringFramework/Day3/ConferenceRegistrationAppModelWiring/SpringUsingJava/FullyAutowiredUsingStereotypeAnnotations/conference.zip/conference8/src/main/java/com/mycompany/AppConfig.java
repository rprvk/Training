package com.mycompany;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.mycompany.repository.HibernateSpeakerRepositoryImpl;
import com.mycompany.repository.SpeakerRepository;
import com.mycompany.service.SpeakerService;
import com.mycompany.service.SpeakerServiceImpl;

@Configuration
@ComponentScan({"com.mycompany"})
public class AppConfig {
//	
//	@Bean(name="speakerService")
//	@Scope(value=BeanDefinition.SCOPE_PROTOTYPE)
//	public SpeakerService gerSpeakerService() {
//
//		//SpeakerServiceImpl service = new SpeakerServiceImpl(getSpeakerRepository());
//		SpeakerServiceImpl service = new SpeakerServiceImpl();  //using setter injection
//		return  service;
//	}
//	
//	@Bean(name = "speakerRepository")  //beans for methods for interfaces
//	public SpeakerRepository getSpeakerRepository() {
//		return new HibernateSpeakerRepositoryImpl();
//	} 
	
	
	
}
//we can also put array of packages that we want to scan in componentScan
//with fully autowired we can get rid of bean definitions(using stereotype annotations)
