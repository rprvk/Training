package com.mycompany;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mycompany.repository.HibernateSpeakerRepositoryImpl;
import com.mycompany.repository.SpeakerRepository;
import com.mycompany.service.SpeakerService;
import com.mycompany.service.SpeakerServiceImpl;

@Configuration
public class AppConfig {
	
	@Bean(name="speakerService")
	public SpeakerService gerSpeakerService() {
		
		SpeakerServiceImpl service = new SpeakerServiceImpl();
		service.setRepository(getSpeakerRepository());  //setting injections

		return  service;
	}
	@Bean(name = "speakerRepository")  //beans for methods for interfaces
	public SpeakerRepository getSpeakerRepository() {
		return new HibernateSpeakerRepositoryImpl();
	}
}
