package com.mycompany.service;

import java.util.List;

import com.mycompany.model.Speaker;
import com.mycompany.repository.SpeakerRepository;

public class SpeakerServiceImpl implements SpeakerService {

	private SpeakerRepository repository;//private SpeakerRepository repository = new HibernateSpeakerRepositoryImpl();
												//now it is no more hardcoded
	
	@Override
	public List<Speaker> findAll() {  //using finder methods

		return repository.findAll();
	}

	public void setRepository(SpeakerRepository repository) {
		this.repository = repository;
	}

}