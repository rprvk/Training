package com.mycompany.repository;

import java.util.ArrayList;
import java.util.List;

import com.mycompany.model.Speaker;

public class HibernateSpeakerRepositoryImpl implements SpeakerRepository {

	@Override
	public List<Speaker> findAll() {

		List<Speaker> speakers = new ArrayList<>();

		Speaker speaker = new Speaker();

		speaker.setFirstName("Billy");
		speaker.setLastName("Idol");

		speakers.add(speaker);

		return speakers;
	}

}

//spring is interface driven. So we can fill in from actual db portion later
//there are different ways to create and extract an interface
//this class is our repository implementation

//methods of speaker repo are implemented here finally