package com.mycompany;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.mycompany.repository.HibernateSpeakerRepositoryImpl;
import com.mycompany.repository.SpeakerRepository;
import com.mycompany.service.SpeakerService;
import com.mycompany.service.SpeakerServiceImpl;

@Configuration
public class AppConfig {
	
	@Bean(name="speakerService")
	@Scope(value=BeanDefinition.SCOPE_SINGLETON)
	public SpeakerService gerSpeakerService() {
		
//		SpeakerServiceImpl service = new SpeakerServiceImpl();
//		service.setRepository(getSpeakerRepository());  //setting injections

		SpeakerServiceImpl service = new SpeakerServiceImpl(getSpeakerRepository());
		return  service;
	}
	@Bean(name = "speakerRepository")  //beans for methods for interfaces
	public SpeakerRepository getSpeakerRepository() {
		return new HibernateSpeakerRepositoryImpl();
	} 
}
