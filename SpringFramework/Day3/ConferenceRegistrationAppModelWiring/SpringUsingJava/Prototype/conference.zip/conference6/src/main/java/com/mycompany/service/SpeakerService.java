package com.mycompany.service;

import java.util.List;

import com.mycompany.model.Speaker;

public interface SpeakerService {
	List<Speaker> findAll();

	
}
//speaker service calls the implementation