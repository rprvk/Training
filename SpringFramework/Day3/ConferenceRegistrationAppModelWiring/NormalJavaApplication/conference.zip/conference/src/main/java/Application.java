import com.mycompany.service.SpeakerService;
import com.mycompany.service.SpeakerServiceImpl;

public class Application {
	public static void main(String[] args) {
		SpeakerService service = new SpeakerServiceImpl();
		System.out.println(service.findAll().get(0).getFirstName());
		
	}
}
//here this main method will execute all other pieces of code
//here get(0) is used because in list we have only one name and in list
               //it starts form  0

//class application calls speakerservice interface that implements methods