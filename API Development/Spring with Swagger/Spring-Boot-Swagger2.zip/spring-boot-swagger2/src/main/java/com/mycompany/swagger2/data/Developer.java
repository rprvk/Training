package com.mycompany.swagger2.data;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="DEVELOPER")
public class Developer implements Serializable {
	private static final long serialVersionUID=1L;
	@Id
	@GeneratedValue
	private Integer developer_id;
	@Column(name="FIRST_NAME")
	private String firstName;
	@Column(name="LAST_NAME")
	private String lastName;
	@Column(name="TEAM_NAME")
	private String teamName;
	
	@OneToOne
	@JoinColumn(name="TASK_ID", insertable=false,updatable=false)  //in order not to put manually and anybody can change we put false in insertable
	private JiraTask jiraTask;

	public Integer getDeveloper_id() {
		return developer_id;
	}

	public void setDeveloper_id(Integer developer_id) {
		this.developer_id = developer_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public JiraTask getJiraTask() {
		return jiraTask;
	}

	public void setJiraTask(JiraTask jiraTask) {
		this.jiraTask = jiraTask;
	}
	
	

}