package com.example.SpringLoginFrom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.SpringLoginFrom.services.UserService;

@Controller
public class LoginController {
	
	private UserService userService;

    @Autowired
    public void setProductService(UserService productService) {
        this.userService = productService;
    }
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage() {
		return "login";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String welcomePage(ModelMap  model ,@RequestParam String userId, @RequestParam String password) {
		boolean isValidUser = userService.isValidUser(userId, password);
		if(isValidUser) {
			model.put("userId", userId);
			return "Welcome";
		}
		model.put("errorMsg", "Please provide correct userid and password !!");
		return "login";
	}
}
