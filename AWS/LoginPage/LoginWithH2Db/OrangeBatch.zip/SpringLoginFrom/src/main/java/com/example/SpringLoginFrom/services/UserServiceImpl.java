package com.example.SpringLoginFrom.services;

import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringLoginFrom.domain.User;
import com.example.SpringLoginFrom.repositories.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private UserRepository userRepository;

    @Autowired
    public void setProductRepository(UserRepository productRepository) {
        this.userRepository = productRepository;
    }

	@Override
	public boolean isValidUser(String username, String password) {
		logger.debug("isValidUser called");
		Iterable<User> users = userRepository.findAll();
		Iterator<User> userIterator = users.iterator();
		while (userIterator.hasNext()) {
			User user = userIterator.next();
			if(username.equals(user.getUserName()) && password.equals(user.getPassword())) {
				return true;
			}
		}
		
		return false;
	}

	@Override
	public User saveUser(User user) {
		logger.debug("saveUser called");
        return userRepository.save(user);
	}

	@Override
	public Iterable<User> listAllUsers() {
		logger.debug("listAllUsers called");
        return userRepository.findAll();
	}

}
