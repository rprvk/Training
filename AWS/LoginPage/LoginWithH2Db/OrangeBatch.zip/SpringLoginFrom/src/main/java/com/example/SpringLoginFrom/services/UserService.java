package com.example.SpringLoginFrom.services;

import com.example.SpringLoginFrom.domain.User;

public interface UserService {
	boolean isValidUser(String username, String password);
	
	User saveUser(User user);
	
	Iterable<User> listAllUsers();
}
