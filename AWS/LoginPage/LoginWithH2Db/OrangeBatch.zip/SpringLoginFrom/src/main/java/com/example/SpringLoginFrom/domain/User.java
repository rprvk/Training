package com.example.SpringLoginFrom.domain;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name="User")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "The database generated user ID")
    @Column(name="ID")
    private Integer id;

    @ApiModelProperty(notes = "The user name")
    @Column(name="USER_NAME")
    private String userName;
    
	@ApiModelProperty(notes = "The password")
    @Column(name="PASSWORD")
    private String password;
    
    @ApiModelProperty(notes = "The role")
    @Column(name="ROLE")
    private String role;
  
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}