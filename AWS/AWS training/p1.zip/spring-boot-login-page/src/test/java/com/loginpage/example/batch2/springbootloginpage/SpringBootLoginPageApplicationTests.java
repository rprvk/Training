package com.loginpage.example.batch2.springbootloginpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLoginPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
