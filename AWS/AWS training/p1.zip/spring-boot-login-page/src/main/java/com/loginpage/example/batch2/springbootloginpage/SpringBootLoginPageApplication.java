package com.loginpage.example.batch2.springbootloginpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLoginPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLoginPageApplication.class, args);
	}

}
