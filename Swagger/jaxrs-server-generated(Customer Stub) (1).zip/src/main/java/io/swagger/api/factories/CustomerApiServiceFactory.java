package io.swagger.api.factories;

import io.swagger.api.CustomerApiService;
import io.swagger.api.impl.CustomerApiServiceImpl;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2022-02-06T07:53:40.637Z")
public class CustomerApiServiceFactory {
    private final static CustomerApiService service = new CustomerApiServiceImpl();

    public static CustomerApiService getCustomerApi() {
        return service;
    }
}
