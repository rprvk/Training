package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.CustomerApiService;
import io.swagger.api.factories.CustomerApiServiceFactory;

import io.swagger.annotations.ApiParam;
import io.swagger.jaxrs.*;

import io.swagger.model.Customer;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;

@Path("/customer")


@io.swagger.annotations.Api(description = "the customer API")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2022-02-06T07:53:40.637Z")
public class CustomerApi  {
   private final CustomerApiService delegate;

   public CustomerApi(@Context ServletConfig servletContext) {
      CustomerApiService delegate = null;

      if (servletContext != null) {
         String implClass = servletContext.getInitParameter("CustomerApi.implementation");
         if (implClass != null && !"".equals(implClass.trim())) {
            try {
               delegate = (CustomerApiService) Class.forName(implClass).newInstance();
            } catch (Exception e) {
               throw new RuntimeException(e);
            }
         } 
      }

      if (delegate == null) {
         delegate = CustomerApiServiceFactory.getCustomerApi();
      }

      this.delegate = delegate;
   }

    @POST
    
    @Consumes({ "application/json" })
    @Produces({ "text/plain" })
    @io.swagger.annotations.ApiOperation(value = "adds a new customer.", notes = "Add a new customer to the system.", response = Integer.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "BasicAuth")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "Successful operation", response = Integer.class),
        
        @io.swagger.annotations.ApiResponse(code = 405, message = "Invalid input", response = Void.class) })
    public Response addCustomer(@ApiParam(value = "The new customer data in Json format" ,required=true) Customer body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.addCustomer(body,securityContext);
    }
    @DELETE
    @Path("/{customerId}")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Delete an existing customer", notes = "Deletes an existing customer in this system.", response = Customer.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "BasicAuth")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "The customer was deleted.", response = Customer.class),
        
        @io.swagger.annotations.ApiResponse(code = 404, message = "Customer Not Found.", response = Void.class),
        
        @io.swagger.annotations.ApiResponse(code = 500, message = "Internal Server Error.", response = Void.class) })
    public Response deleteCustomer(@ApiParam(value = "The Id of the customer to update.",required=true) @PathParam("customerId") Integer customerId
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.deleteCustomer(customerId,securityContext);
    }
    @GET
    
    
    @Produces({ "application/json", "application/xml", "text/xml", "text/cvs" })
    @io.swagger.annotations.ApiOperation(value = "reads a cutomer's data", notes = "This operation provides a view of the customers data in JSON. the operation used the customer id to identity the customer  in a query string.", response = Customer.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "BasicAuth")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "search results mathching criteria.", response = Customer.class),
        
        @io.swagger.annotations.ApiResponse(code = 404, message = "employee with this id does not exist.", response = Void.class) })
    public Response getCustomer(@ApiParam(value = "pass a customer id to get customer data.",required=true) @QueryParam("customerId") Integer customerId
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getCustomer(customerId,securityContext);
    }
    @PUT
    @Path("/{customerId}")
    @Consumes({ "application/json" })
    
    @io.swagger.annotations.ApiOperation(value = "update an existing customer", notes = "updates an existing customer with new data", response = Void.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "BasicAuth")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "Success.", response = Void.class),
        
        @io.swagger.annotations.ApiResponse(code = 404, message = "Customer Not Found.", response = Void.class),
        
        @io.swagger.annotations.ApiResponse(code = 500, message = "Internal Server Error.", response = Void.class) })
    public Response updateCustomer(@ApiParam(value = "The updated customer data in JSON formar" ,required=true) Customer body
,@ApiParam(value = "The Id of the customer to update.",required=true) @PathParam("customerId") Integer customerId
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.updateCustomer(body,customerId,securityContext);
    }
}
