package io.swagger.api;

import io.swagger.api.*;
import io.swagger.model.*;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;

import io.swagger.model.Customer;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2022-02-06T07:53:40.637Z")
public abstract class CustomerApiService {
    public abstract Response addCustomer(Customer body,SecurityContext securityContext) throws NotFoundException;
    public abstract Response deleteCustomer(Integer customerId,SecurityContext securityContext) throws NotFoundException;
    public abstract Response getCustomer( @NotNull Integer customerId,SecurityContext securityContext) throws NotFoundException;
    public abstract Response updateCustomer(Customer body,Integer customerId,SecurityContext securityContext) throws NotFoundException;
}
