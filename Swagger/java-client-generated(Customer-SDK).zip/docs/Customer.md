
# Customer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerId** | **Integer** |  |  [optional]
**accountValue** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**customerName** | **String** |  |  [optional]
**active** | **Boolean** |  |  [optional]
**address** | **Object** |  |  [optional]
**contacts** | **List&lt;Object&gt;** |  |  [optional]



