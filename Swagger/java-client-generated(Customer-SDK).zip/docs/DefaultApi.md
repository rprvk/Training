# DefaultApi

All URIs are relative to *http://api.globalmantics.com/crm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addCustomer**](DefaultApi.md#addCustomer) | **POST** /customer | adds a new customer.
[**deleteCustomer**](DefaultApi.md#deleteCustomer) | **DELETE** /customer/{customerId} | Delete an existing customer
[**getCustomer**](DefaultApi.md#getCustomer) | **GET** /customer | reads a cutomer&#39;s data
[**updateCustomer**](DefaultApi.md#updateCustomer) | **PUT** /customer/{customerId} | update an existing customer


<a name="addCustomer"></a>
# **addCustomer**
> Integer addCustomer(body)

adds a new customer.

Add a new customer to the system.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.DefaultApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");

DefaultApi apiInstance = new DefaultApi();
Customer body = new Customer(); // Customer | The new customer data in Json format
try {
    Integer result = apiInstance.addCustomer(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#addCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Customer**](Customer.md)| The new customer data in Json format |

### Return type

**Integer**

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

<a name="deleteCustomer"></a>
# **deleteCustomer**
> Customer deleteCustomer(customerId)

Delete an existing customer

Deletes an existing customer in this system.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.DefaultApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");

DefaultApi apiInstance = new DefaultApi();
Integer customerId = 56; // Integer | The Id of the customer to update.
try {
    Customer result = apiInstance.deleteCustomer(customerId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#deleteCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **Integer**| The Id of the customer to update. |

### Return type

[**Customer**](Customer.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCustomer"></a>
# **getCustomer**
> Customer getCustomer(customerId)

reads a cutomer&#39;s data

This operation provides a view of the customers data in JSON. the operation used the customer id to identity the customer  in a query string.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.DefaultApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");

DefaultApi apiInstance = new DefaultApi();
Integer customerId = 56; // Integer | pass a customer id to get customer data.
try {
    Customer result = apiInstance.getCustomer(customerId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#getCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **Integer**| pass a customer id to get customer data. |

### Return type

[**Customer**](Customer.md)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/xml, text/cvs

<a name="updateCustomer"></a>
# **updateCustomer**
> updateCustomer(body, customerId)

update an existing customer

updates an existing customer with new data

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.DefaultApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");

DefaultApi apiInstance = new DefaultApi();
Customer body = new Customer(); // Customer | The updated customer data in JSON formar
Integer customerId = 56; // Integer | The Id of the customer to update.
try {
    apiInstance.updateCustomer(body, customerId);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#updateCustomer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Customer**](Customer.md)| The updated customer data in JSON formar |
 **customerId** | **Integer**| The Id of the customer to update. |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

