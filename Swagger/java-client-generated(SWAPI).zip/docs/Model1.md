
# Model1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**height** | **String** |  |  [optional]
**mass** | **String** |  |  [optional]
**hairColor** | **String** |  |  [optional]
**skinColor** | **String** |  |  [optional]
**eyeColor** | **String** |  |  [optional]
**birthYear** | **String** |  |  [optional]
**gender** | **String** |  |  [optional]
**homeworld** | **String** |  |  [optional]
**films** | **List&lt;String&gt;** |  |  [optional]
**species** | **List&lt;String&gt;** |  |  [optional]
**vehicles** | [****](.md) |  |  [optional]
**starships** | [****](.md) |  |  [optional]
**created** | **String** |  |  [optional]
**edited** | **String** |  |  [optional]
**url** | **String** |  |  [optional]



