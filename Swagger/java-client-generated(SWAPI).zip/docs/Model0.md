
# Model0

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Integer** |  |  [optional]
**next** | **Object** |  |  [optional]
**previous** | **Object** |  |  [optional]
**results** | [**List&lt;Results&gt;**](Results.md) |  |  [optional]



