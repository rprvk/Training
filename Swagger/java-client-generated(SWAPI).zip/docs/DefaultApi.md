# DefaultApi

All URIs are relative to *http://swapi.dev/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**peopleCharacterIdGet**](DefaultApi.md#peopleCharacterIdGet) | **GET** /people/{characterId} | 
[**peopleGet**](DefaultApi.md#peopleGet) | **GET** /people/ | 
[**peopleGet_0**](DefaultApi.md#peopleGet_0) | **GET** /people | 


<a name="peopleCharacterIdGet"></a>
# **peopleCharacterIdGet**
> Model1 peopleCharacterIdGet(characterId)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Integer characterId = 56; // Integer | 
try {
    Model1 result = apiInstance.peopleCharacterIdGet(characterId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#peopleCharacterIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **characterId** | **Integer**|  |

### Return type

[**Model1**](Model1.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="peopleGet"></a>
# **peopleGet**
> Model0 peopleGet(search)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String search = "search_example"; // String | 
try {
    Model0 result = apiInstance.peopleGet(search);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#peopleGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **String**|  | [optional]

### Return type

[**Model0**](Model0.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="peopleGet_0"></a>
# **peopleGet_0**
> peopleGet_0()



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.peopleGet_0();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#peopleGet_0");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

