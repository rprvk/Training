package com.sprint1.evaluation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication
public class SpringBootSwagger2EvaluationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSwagger2EvaluationApplication.class, args);
	}

}
