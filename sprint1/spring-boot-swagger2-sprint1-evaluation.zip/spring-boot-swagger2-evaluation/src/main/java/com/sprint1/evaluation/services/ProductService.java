package com.sprint1.evaluation.services;

import com.sprint1.evaluation.domain.Product;

public interface ProductService {

	public Iterable<Product> listAllProducts();

	public void saveProduct(Product product);

	public void deleteProduct(Integer id);

	public Product getProductById(Integer id);
	

}
