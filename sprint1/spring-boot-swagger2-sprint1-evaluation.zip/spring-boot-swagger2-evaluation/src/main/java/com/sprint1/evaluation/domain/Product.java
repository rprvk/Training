package com.sprint1.evaluation.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table
//@Table(name="PRODUCT")  //can also be declared like this
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) //AUTO|IDENTITY almost same
	@Column(name = "ID")
	@ApiModelProperty(notes = "The database generated product ID")
	private Integer Id;

	@Column(name = "PRODUCT_ID")
	@ApiModelProperty(notes = "The application-specific product ID")
	private Integer productId;

	@Column(name = "VERSION")
	@Version
	@ApiModelProperty(notes = "The auto-generated version of the product")
	private Integer version;

	@Column(name = "DESCRIPTION")
	@ApiModelProperty(notes = "The product description")
	private String description;

	@Column(name = "IMAGE_URL")
	@ApiModelProperty(notes = "The image URL of the product")
	private String imageUrl;

	@Column(name = "PRICE")
	@ApiModelProperty(notes = "The price of the product", required = true)
	private BigDecimal price;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	

}
