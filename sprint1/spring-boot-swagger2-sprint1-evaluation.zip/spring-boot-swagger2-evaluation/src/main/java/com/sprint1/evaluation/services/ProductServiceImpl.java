package com.sprint1.evaluation.services;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint1.evaluation.domain.Product;
import com.sprint1.evaluation.repositories.ProductRepository;

@Service  //then only autowired works. It now acts as bean
public class ProductServiceImpl implements ProductService {
	
	private final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	
	@Autowired
	private ProductRepository productRepository;
	
	public Iterable<Product> listAllProducts(){
		logger.debug("listAllProducts called  and");
		return productRepository.findAll();
	}

	@Override
	public void saveProduct(Product product) {
		productRepository.save(product);
		logger.trace("called saveProduct and Product is saved");
	}

	@Override
	public void deleteProduct(Integer id) {
		productRepository.deleteById(id);
		logger.trace("called deleteProduct and Product deleted");
	}

	@Override
	public Product getProductById(Integer id) {
		Optional<Product> op = productRepository.findById(id);
		logger.trace("called getProductById and Finding product");
		return op.get();
	}
	
	public ProductRepository getProductRepository() {
		return productRepository;
	}

	@Autowired
	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

   
}
