package com.mycompany.model.jpa;

public enum RoleType {
    USER, ADMIN, OPERATOR, CUSTOMER
}
