package com.bobocode.model;

public enum Gender {
    MALE,
    FEMALE
}
