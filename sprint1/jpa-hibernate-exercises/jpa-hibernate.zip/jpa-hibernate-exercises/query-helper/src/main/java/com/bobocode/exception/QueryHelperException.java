package com.bobocode.exception;

public class QueryHelperException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QueryHelperException(String message, Throwable cause) {
        super(message, cause);
    }
}
