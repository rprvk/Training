package com.mycompany.jpa.airport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PASSENGERS")
public class Passenger {
	@Id
	@Column(name = "ID")
	private int id;

	@Column(name = "NAME")
	private String name;

	public Passenger(int id, String name) {
		this.id = id;
		this.name = name;
	}

	@ManyToOne
	@JoinColumn(name = "AIRPORT_ID") // airport id is foreign key //different people in same airport for flight
	private Airport airport;

	// now we need list of tickets

	@OneToMany(mappedBy = "passenger")
	private List<Ticket> tickets = new ArrayList<>();

	public Airport getAirport() {
		return airport;
	}

	public void setAirport(Airport airport) {
		this.airport = airport;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Ticket> getTickets() {
		return Collections.unmodifiableList(tickets);
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public void addTicket(Ticket ticket) { // it will add tickets to the passengers list of tickets
		tickets.add(ticket);
	}

}
