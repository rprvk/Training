package com.mycompany.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.mycompany.jpa.airport.Airport;
import com.mycompany.jpa.airport.Passenger;
import com.mycompany.jpa.airport.Ticket;

public class Main {

	public static void main(String[] args) {
		// this is application manager container
		// here are building project and setting jpa with hibernate and sql

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m02.ex01");
		EntityManager em = emf.createEntityManager(); // this contains set of methods to update,delete etc.

		em.getTransaction().begin();

		Airport airport = new Airport(1, "Henri Coanda");

		Passenger john = new Passenger(1, "John Smith");
		john.setAirport(airport);
		Passenger mike = new Passenger(2, "Michael Johnson"); // mike also taking flight from same airport
		mike.setAirport(airport);

		// adding passenger to airport obj
		airport.addPassenger(john);
		airport.addPassenger(mike);

		// create tickets
		Ticket ticket1 = new Ticket(1, "AA1234");
		ticket1.setPassenger(john);

		Ticket ticket2 = new Ticket(2, "BB5678");
		ticket2.setPassenger(john);

		// adding tickets to john //addeTicket method in passengers class
		john.addTicket(ticket1);
		john.addTicket(ticket2);

		Ticket ticket3 = new Ticket(3, "CC0987");
		ticket3.setPassenger(mike);
		mike.addTicket(ticket3);

		// now we need to persist all the tickets one by one, means insert into db
		em.persist(airport);
		em.persist(john);
		em.persist(mike);

		em.persist(ticket1);
		em.persist(ticket2);
		em.persist(ticket3);

		em.getTransaction().commit();
		emf.close();

	}

}
