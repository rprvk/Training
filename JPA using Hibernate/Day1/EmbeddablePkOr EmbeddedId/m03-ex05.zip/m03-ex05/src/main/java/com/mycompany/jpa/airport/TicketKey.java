package com.mycompany.jpa.airport;

import java.io.Serializable;

import javax.persistence.Embeddable;

//means the obj of this class will be embedded into some other class

@Embeddable
public class TicketKey implements Serializable{  //for seriaLization
	private String number;
	private String series;
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}

}
