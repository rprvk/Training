package com.mycompany.jpa.airport;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TICKETS")
public class Ticket {
	
	@EmbeddedId 
	private TicketKey id;
	 /*it is embedded from embeddable ticketKey class. So now series and number together will 
	form the primary key Id*/
	

	public TicketKey getId() {
		return id;
	}

	public void setId(TicketKey id) {
		this.id = id;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	private String origin;
	private String destination;
	

	public Ticket() {

	}

	public Ticket(TicketKey id, String origin, String destination) {
		this.id = id;
		this.origin = origin;
		this.destination = destination;
	}

}
/*
 #primary key can be created using @generatedValue
 */
