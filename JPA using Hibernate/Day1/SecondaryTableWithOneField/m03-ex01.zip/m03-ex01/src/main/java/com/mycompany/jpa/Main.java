package com.mycompany.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.mycompany.jpa.airport.Passenger;

public class Main {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m03.ex01");
		EntityManager em = emf.createEntityManager(); 
		em.getTransaction().begin();

		//now we create an passenger and give id,name,address
		Passenger john = new Passenger(1, "John Smith", "3 Flowers Street, Boston");
				
		em.persist(john);


		em.getTransaction().commit();
		emf.close();

	}

}

/*
    select * from public.addresses
    order by passenger_id ASC
    ___________________________________ 
    select * from addresses;
    ===============================================
    
       select * from public.passengers
    order by passenger_id ASC
    ___________________________________ 
    select * from passengers;
    
*/
 
