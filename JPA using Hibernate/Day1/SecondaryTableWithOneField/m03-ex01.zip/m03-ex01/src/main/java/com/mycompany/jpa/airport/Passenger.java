package com.mycompany.jpa.airport;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import javax.persistence.PrimaryKeyJoinColumn;

/*
 * here we are specifying two tables in one class(entity class)
 * They are table PASSENGERS and table ADDRESSES
 #  "joincolumn" key is used to mapping. Here it  maps the  foreign key(passenger id)of address table
    to passenger id of primary table(passengers table)  
 */

@Entity
@Table(name = "PASSENGERS")
@SecondaryTable(name = "ADDRESSES",
pkJoinColumns = @PrimaryKeyJoinColumn(name = "PASSENGER_ID", referencedColumnName = "PASSENGER_ID" ))
public class Passenger {
	@Id
	@Column(name = "PASSENGER_ID")
	private int id;
	
	@Column(name = "PASSENGER_NAME", table="PASSENGERS")
	private String name;

	//to get passenger address
	@Column(name = "PASSENGER_ADDRESS", table="ADDRESSES", columnDefinition = "varchar(25) not null" )
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public Passenger(){
		
	}

	public Passenger(int id, String name,String address) {
		this.id = id;
		this.name = name;
		this.address=address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
