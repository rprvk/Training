package com.mycompany.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.mycompany.jpa.airport.Passenger;
import com.mycompany.jpa.airport.Ticket;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m04.ex06");
		EntityManager em = emf.createEntityManager(); // this contains set of methods to update,delete etc.

		em.getTransaction().begin();

		Passenger john = new Passenger("John Smith");

		Ticket ticket1 = new Ticket("AA1234");
		Ticket ticket2 = new Ticket("BB5678");

		john.addTicket(ticket1);
		john.addTicket(ticket2);

		em.persist(john);

		em.getTransaction().commit();
		emf.close();

	}

}
/*
 * what is different from before?
 * here we have'nt set id here. Because @GeneratedValue and auto will automatically generate
  and increment value.
 */

	
