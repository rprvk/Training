package com.mycompany.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.mycompany.jpa.airport.Address;
import com.mycompany.jpa.airport.Passenger;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m04.ex05");
		EntityManager em = emf.createEntityManager(); // this contains set of methods to update,delete etc.

		em.getTransaction().begin();

		Passenger john = new Passenger("John Smith");
		Address address = new Address();

		address.setStreet("Flowers Street");
		address.setNumber("3");
		address.setZipCode("012345");
		address.setCity("Boston");

		john.setAddress(address);

		em.persist(john);

		em.getTransaction().commit();
		emf.close();

	}

}
/*
 * what is different from before?
 * here we have'nt set id here. Because @GeneratedValue and auto will automatically generate
  and increment value.
 */

	
