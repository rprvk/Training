package com.mycompany.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;

import com.mycompany.jpa.airport.Ticket;

public class Main {

	public static void main(String[] args) {
		// this is application manager container
		// here are building project and setting jpa with hibernate and sql

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m03.ex04");
		EntityManager em = emf.createEntityManager(); // this contains set of methods to update,delete etc.

		em.getTransaction().begin();

//		Ticket ticket1 = new Ticket(1, "AA1234"); //instead of this lets take a default constructor
		Ticket ticket1 = new Ticket();
		ticket1.setSeries("AA");
		ticket1.setNumber("1234");
		ticket1.setOrigin("Bucharest");
		ticket1.setDestination("London");
		
		em.persist(ticket1);
		
		em.getTransaction().commit();
		
		//using EntityManager.find()
		Ticket foundTicket=em.find(Ticket.class, 1);
		System.out.println("The ticket with ID  1 found is"+foundTicket);
		 
		//using JPQL to find aN Entity
		foundTicket = em.createQuery("select t from Ticket t where t.id=1",Ticket.class).getSingleResult();
		System.out.println("The ticket with ID  1 found by JPQL is"+foundTicket);
		
		//JPA Criteria API
		//JPQL select c from Country c;
		
		 CriteriaBuilder cb = em.getCriteriaBuilder();  //it works on objs.
		 
		 CriteriaQuery<Ticket> q= cb.createQuery(Ticket.class);  //builds criteria
		 
		 Root<Ticket>c= q.from(Ticket.class); //selecting range
		 q.select(c); //to execute query in this class itself
		 
		 //upto now it is criteria query. Now to change to TypeQuery which was introduced in Jpa2
		 TypedQuery<Ticket> query = em.createQuery(q);
		 
		 List<Ticket> results = query.getResultList();	
		 
		 for(Ticket ticket:results) {
			 System.out.println("The ticket with ID  1 found by CriteriaQuery is"+ticket);
			 
		 }
				 
		 
		 
		 
		 
		
		emf.close();

	}

}
/*
 * what is different from before?
 * here we have'nt set id here. Because @GeneratedValue and auto will automatically generate
  and increment value.
 */

	
