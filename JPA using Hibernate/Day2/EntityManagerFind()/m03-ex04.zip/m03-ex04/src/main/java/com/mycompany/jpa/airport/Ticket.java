package com.mycompany.jpa.airport;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TICKETS")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)   //it automatically increases value
	private int id;

	private String series;
	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	private String number;
	private String origin;
	private String destination;
	

	public Ticket() {

	}

	public Ticket(int id, String number) {
		this.id = id;
		this.number=number;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", series=" + series + ", number=" + number + ", origin=" + origin
				+ ", destination=" + destination + "]";
	}

}
/*
 #primary key can be created using @generatedValue
 */
