package com.mycompany.jpa.airport;

import java.time.LocalDate;

import javax.persistence.AssociationOverride;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name = "RETURN_TICKET" )
@AssociationOverride(name = "passenger" , joinColumns = @JoinColumn(name = "pass_id"))

public class ReturnTicket extends Ticket {

	private LocalDate latestReturnDate;

	public LocalDate getLatestReturnDate() {
		return latestReturnDate;
	}

	public void setLatestReturnDate(LocalDate latestReturnDate) {
		this.latestReturnDate = latestReturnDate;
	}

}
