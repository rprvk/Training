package com.mycompany.jpa.airport;

import java.time.LocalDate;

import javax.persistence.Entity;

@Entity
public class OneWayTicket extends Ticket {
	
	private LocalDate latestDepartureDate;

	public LocalDate getLatestDepartureDate() {
		return latestDepartureDate;
	}

	public void setLatestDepartureDate(LocalDate latestDepartureDate) {
		this.latestDepartureDate = latestDepartureDate;
	}
}
//in some cases like this we will have @Entity without @Id or @Column