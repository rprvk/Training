package com.mycompany.hibernatejpa.airport;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class CountryService {
	
	@PersistenceContext //we inject the EM that is declared in bean in application.context/xml by using persistenceContext
	private EntityManager em;

    public static final String[][] COUNTRY_INIT_DATA = {{"Australia", "AU"}, {"Canada", "CA"}, {"France", "FR"},
            {"Germany", "DE"}, {"Italy", "IT"}, {"Japan", "JP"}, {"Romania", "RO"},
            {"Russian Federation", "RU"}, {"Spain", "ES"}, {"Switzerland", "CH"},
            {"United Kingdom", "UK"}, {"United States", "US"}};

    @Transactional  //no need to use begin And commit, it will run automatically //but wont call until persisted
     												//so no need to explicitly use begin and commit
    public void init() {
        for (int i = 0; i < COUNTRY_INIT_DATA.length; i++) {
            String[] countryInitData = COUNTRY_INIT_DATA[i];
            Country country = new Country(countryInitData[0], countryInitData[1]);
			em.persist(country);  //persisting
        }
    }

    @Transactional
    public void clear() {
    	em.createQuery("delete from Country c").executeUpdate();
    }

    public List<Country> getAllCountries() { //retrieve data from db
        return em.createQuery("select c from Country c").getResultList();
    }

}
