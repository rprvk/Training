package com.mycompany.jpa.airport;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@Table(name = "PASSENGERS")
public class Passenger {
	@Id
	@GeneratedValue
	@Column(name = "PASSENGER_ID")
	private int id;
	
	@Column(name = "PASSENGER_NAME")
	private String name;
 
	@OneToMany(mappedBy = "passenger")
	private List<Ticket> tickets = new ArrayList<>();

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}
//	public List<Ticket> getTickets() {
//		return tickets;
//	}
//  in order not to alter tickets we declare as follows
	public List<Ticket> getTickets() {
		return Collections.unmodifiableList(tickets);
	}

	public void addTicket(Ticket ticket) {
		tickets.add(ticket);
	}

	public Passenger(){
		
	}
	
	public Passenger(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
