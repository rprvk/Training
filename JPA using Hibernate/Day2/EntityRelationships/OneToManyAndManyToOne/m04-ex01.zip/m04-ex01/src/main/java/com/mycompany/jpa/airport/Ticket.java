package com.mycompany.jpa.airport;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/*
 * here using @IdClass to created embedded id
 */
@Entity
@Table(name = "TICKETS")
public class Ticket {

	@Id
	@GeneratedValue
	@Column(name = "ID")
	private int id;
	private String number;

	@ManyToOne
	@JoinColumn(name = "PASSENGER_ID")
	private Passenger passenger;

	public String getNumber() { 
		return number;
	}

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	// since id is generzated by generatedValue and comes from db side, no need this in cons
	public Ticket() {

	}

	public Ticket(String number) {
		this.number = number;
	}
}
/*
 * #primary key can be created using @generatedValue
 */
