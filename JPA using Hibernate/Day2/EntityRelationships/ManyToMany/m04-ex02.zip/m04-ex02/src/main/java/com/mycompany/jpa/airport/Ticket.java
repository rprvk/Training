package com.mycompany.jpa.airport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TICKETS")
public class Ticket {

	@Id
	@GeneratedValue
	@Column(name = "ID")
	private int id;
	private String number;

	@ManyToMany
	//@JoinColumn(name = "PASSENGER_ID")    //it will pick on its own
	private List<Passenger> passengers=new ArrayList<>();

	public String getNumber() { 
		return number; 
	}

	public List<Passenger> getPassengers() {
		return Collections.unmodifiableList(passengers);
	}

	public void addPassengers(Passenger passenger) {
		passengers.add(passenger);
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Ticket() {

	}

	public Ticket(String number) {
		this.number = number;
	}

	
}
/*
 * #primary key can be created using @generatedValue
 */
