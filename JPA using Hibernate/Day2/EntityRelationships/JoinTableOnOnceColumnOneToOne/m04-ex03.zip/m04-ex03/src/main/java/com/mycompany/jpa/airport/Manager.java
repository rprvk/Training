package com.mycompany.jpa.airport;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="MANAGERS")  
public class Manager {
	@Id
	@GeneratedValue
	private int id;
	
	private String name;
	
	@OneToOne
	@JoinTable(name="MANAGER_TO_DEPARTMENT",joinColumns= {@JoinColumn(name="MANAGER_ID",referencedColumnName = "ID")},
	inverseJoinColumns = {@JoinColumn(name="DEPARTMENT_ID",referencedColumnName = "ID",nullable=false)})
	private Department department;

	public Manager() {
	}

	public Manager(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public void setId(int id) {
		this.id = id;
	}

}
