package com.mycompany.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.mycompany.jpa.airport.Department;
import com.mycompany.jpa.airport.Manager;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m04.ex03");
		EntityManager em = emf.createEntityManager(); // this contains set of methods to update,delete etc.

		em.getTransaction().begin();


		Manager john = new Manager("John Smith");
		Department accounting = new Department();

		accounting.setName("Accounting");
		john.setDepartment(accounting);

		em.persist(john);

		em.persist(accounting);


		
		em.getTransaction().commit();
		emf.close();

	}

}
/*
 * what is different from before?
 * here we have'nt set id here. Because @GeneratedValue and auto will automatically generate
  and increment value.
 */

	
