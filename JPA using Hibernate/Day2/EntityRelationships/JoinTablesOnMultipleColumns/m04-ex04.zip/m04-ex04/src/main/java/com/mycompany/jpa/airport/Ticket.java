package com.mycompany.jpa.airport;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TICKETS")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)   //it automatically increases value
	private int id;
	
	private String number;
	private String origin;
	private String destination;
	

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Ticket() {

	}

	public Ticket(int id, String number) {
		this.id = id;
		this.number=number;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
/*
 #primary key can be created using @generatedValue
 */
